#!/bin/bash
set -euo pipefail

# 파라미터 확인
if [[ $# -lt 1 ]]; then
  echo "사용법: $0 <IP주소>"
  exit 1
fi

IP="$1"

# 저장 폴더로 이동
cd /home/kali/Documents/upload

# SMB 접속 및 다운로드
smbclient "//$IP/shared" 'Passw0rd!' -U 'admin2' <<EOF
prompt OFF
recurse ON
mget *
quit
EOF

