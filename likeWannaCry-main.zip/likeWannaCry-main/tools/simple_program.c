
#include <stdio.h>

int main() {
    printf("Hello from your custom EXE!\\n");
    printf("Press Enter to exit...");
    getchar();
    return 0;
}
